// Import Student Controller
const PatientController = require("../src/controllers/patients.controller");

// import module validation
const validate = require("../src/validate/validation");


// import module router dan express
const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
    res.send("Hello Express");
});

router.get("/patients", PatientController.index);
router.get("/patients/:id", validate[1], PatientController.show);
router.post("/patients", validate[0], PatientController.store);
router.put("/patients/:id", validate[2], PatientController.update);
router.delete("/patients/:id", validate[1], PatientController.destroy);
router.get("/patients/search/:name", PatientController.search);
router.get("/patients/status/positive", PatientController.positive);
router.get("/patients/status/recovered", PatientController.recovered);
router.get("/patients/status/dead", PatientController.dead);

// Export router
module.exports = router;