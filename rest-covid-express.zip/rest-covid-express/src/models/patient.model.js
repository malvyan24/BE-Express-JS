// import database dan module data types
const { DataTypes } = require("sequelize");
const db = require("../database");

// define data type
const Patient = db.define("patients", {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    status: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    in_date_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    out_date_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

// export module Patient
module.exports = Patient;